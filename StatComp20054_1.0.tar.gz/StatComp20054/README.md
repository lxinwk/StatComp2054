# StatComp

This is a sample package developed for the graduate course "Statistical Computing" at the University of Science and Technology of China.
"# StatComp20054" 
